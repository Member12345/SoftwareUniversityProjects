<?php

namespace SoftUniBlogBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class ErrorController extends Controller
{
    /**
     * @Route("/error", name="error_page")
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function indexAction()
    {
        if(!isset($_SERVER['QUERY_STRING'])){
            $arr['error'] = 'An error occurred.';
        }
        else {
            parse_str($_SERVER['QUERY_STRING'], $arr);
        }
        return $this->render('error/error.html.twig', [
            'error' => $arr['error']
        ]);
    }
}
