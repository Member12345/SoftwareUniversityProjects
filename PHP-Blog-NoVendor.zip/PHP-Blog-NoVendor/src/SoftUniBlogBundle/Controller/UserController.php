<?php

namespace SoftUniBlogBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use SoftUniBlogBundle\Entity\Article;
use SoftUniBlogBundle\Entity\User;
use SoftUniBlogBundle\Form\UserType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class UserController extends Controller
{
    /**
     * @Route("/register", name="user_register")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function registerAction(Request $request){
        $user = new User();
        $form = $this->createForm(UserType::class, $user);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){

            $password = $this->get('security.password_encoder')
                ->encodePassword($user, $user->getPassword());

            $user->setPassword($password);

            $em = $this->getDoctrine()->getManager();
            $em->persist($user);
            $em->flush();

            return $this->redirectToRoute('security_login');

        }
        return $this->render("user/register.html.twig",
            array('form'=>$form->createView())
        );

    }

    /**
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     * @Route("/profile", name="user_profile")
     */
    public function profileAction()
    {
        $authorId = $this->getUser()->getId();
        $articles = $this->getDoctrine()->getRepository(Article::class)->findBy(
            ['authorId' => $authorId],
            ['dateAdded' => 'DESC']);
        $user = $this->getUser();
        if(count($articles) === 0){
            $article = "No recent activity :(";
            $title = "";
        }
        else{
            $article = $articles[0]->getContent();
            $title = $articles[0]->getTitle();
            if(strlen($article) >= 300)
            {
                $article = substr($article, 0, 300) . "...";
            }
        }
        return $this->render("user/profile.html.twig", ['user'=>$user, 'article'=>$article, 'title'=>$title]);
    }

    /**
     * @Security("is_granted('IS_AUTHENTICATED_FULLY')")
     * @Route("/user/articles", name="user_articles")
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function showMyArticles()
    {
        $authorId = $this->getUser()->getId();
        $articles = $this->getDoctrine()->getRepository(Article::class)->findBy(
            ['authorId' => $authorId],
            ['dateAdded' => 'DESC']);
        return $this->render('user/articles.html.twig', [
            'articles' => $articles
        ]);
    }

}
